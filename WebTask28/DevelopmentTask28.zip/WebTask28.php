<?php 

class Person {
	// Pass a new parameter with the name of $message
	function say_hello() {

	}
}

// Create an object of class and call say_hello function with a message e.g "Hello From Class"

?>